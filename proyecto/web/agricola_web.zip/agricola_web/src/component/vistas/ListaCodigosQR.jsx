





import React, { useState, useEffect, useRef, useContext } from 'react';

import { Link, useNavigate } from 'react-router-dom';
import image_logo from '../image/logo_sirculo.jpg';

import { FaBars, FaHome, FaSignInAlt, FaSignOutAlt,FaSearch,FaBoxOpen,FaMapMarkerAlt,FaCalendarAlt,FaAppleAlt,FaCheck  } from "react-icons/fa";
import Sidebar from '../Navbar/Sidebar';

import axios from 'axios';

import { AuthContext } from '../otros/AuthContext';


////

/*
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
*/ 

////

function ListaCodigosQR() {
  if (!window.location.pathname.endsWith('/')) { window.location.href = window.location.pathname + '/'; }
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const toggleSidebar = () => { setSidebarVisible(!sidebarVisible); };

  
  const [qrList, setQrList] = useState([]);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [cantidad, setCantidad] = useState(1);
  const [fechaSeleccionada, setFechaSeleccionada] = useState(null);
/* 
  const [error, setError] = useState(null /* '' */ /* ); 
  
  useEffect(() => {
      const obtenerQRs = async () => {
        try { const resultado = await axios.get('URL_API/listarQRs'); // Ruta de la API para obtener los datos del usuario ejemplo si es de una url seria https://restcountries.com/v3.1/all
        if (!resultado.data || resultado.data.length === 0) { throw new Error('No se obtuvieron datos de la API'); }         
          setQrList(resultado.data);
        } catch (error) {
          console.error('Error al obtener la lista de QRs:', error);
          setError('Error al obtener la lista de QRs: ' + error.message);
        }
      };
      obtenerQRs();
    }, []);  */
  /*    if (!qrList) { return <p>Cargando...</p>; }  */
  
/*  if (error) { return <div>{error}</div>; }  */


/* const handleGenerarQr = async () => {  
  try {
      const nuevosQRs = await axios.post('URL_API/crearQRs', { cantidad, fecha: fechaSeleccionada });
      setQrList([...qrList, ...nuevosQRs.data]);
      setMostrarModal(false);
    } catch (error) { console.error('Error al generar nuevos QRs:', error); }
  };

  const handleDateChange = date => { setFechaSeleccionada(date); };
 */

  const { authenticated, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const handleLogout = () => {
    console.log('Cerrando sesión...');
    localStorage.clear(); // Limpiar el almacenamiento local
    logout();
    navigate('/LoginAdmin');
  };

  const qrTest = [
 
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '22-06-2024'},
    { rutAsociado: 'none', estado: 'Crema', fechaCreado: '22-06-2024'},
 
    { rutAsociado: '20.302.541-2', estado: 'Activado', fechaCreado: '20-06-2024'},
    { rutAsociado: '20.203.145-3', estado: 'Activado', fechaCreado: '21-06-2024'},
    { rutAsociado: 'none', estado: 'Inactivo', fechaCreado: '23-06-2024'},
    { rutAsociado: '30.205.241-2', estado: 'Activado', fechaCreado: '24-06-2024'},
    { rutAsociado: '10.403.225-3', estado: 'Activado', fechaCreado: '24-06-2024'},
/* */
    
  ];

   //para la barra de busqueRut
   const [busqueRUT, setBusqueRUT] = useState('');
   const handbus = (e) => {  
   
    setBusqueRUT(e.target.value); 
  };

  const formatRut = (rut) => {
    const rutDigits = rut.slice(0, -1);
    const rutVerifier = rut.slice(-1);
    let formattedRut = rutDigits.replace(/\./g, ''); // Eliminar puntos existentes
    formattedRut = formattedRut.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.'); // Agregar puntos cada 3 dígitos
    formattedRut = formattedRut + '-' + rutVerifier.toUpperCase(); // Agregar guion al final
    return formattedRut; 
  };

  const handleSubmit = (event) => {
    event.preventDefault();  
  };
 
 
//termino verificacion rut

  const ultimosDatos = qrTest.slice().sort((a, b) => new Date(b.fechaCreado.split('-').reverse().join('/')) - new Date(a.fechaCreado.split('-').reverse().join('/'))); // Ordenar por fecha
   
  const fecFec = [...new Set(qrTest.map(bin => bin.fechaCreado))]; // Obtener fechas 
  const estEst = [...new Set(qrTest.map(bin => bin.estado))]; // Obtener estado 
 
  //para la barra de Filtrado
   // Funciones de filtrado y ordenamiento
   const [filtrarFecha, setFiltrarFecha] = useState('');
   const [filtrarEstado, setFiltrarEstado] = useState('');
   
  const filtrarQR = ultimosDatos.filter(item =>  item.rutAsociado.toLowerCase().includes(busqueRUT.toLowerCase()) &&  (filtrarFecha === ''  || item.fechaCreado === filtrarFecha) && item.estado.toLowerCase().includes(filtrarEstado.toLowerCase()) );

  //para mostrar el contenido paginado por botones
  const itemsPerPage = 21; // Número de elementos por página
  const [currentPage, setCurrentPage] = useState(1);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filtrarQR.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => { setCurrentPage(pageNumber); };
  // ordenamiento de votones
  const totalPages = Math.ceil(filtrarQR.length / itemsPerPage);
  const maxPageButtons = 2; // Número máximo de botones de página hacia adelante y hacia atrás
  const renderPageButtons = () => {
    const pageButtons = [];
    let startPage = Math.max(1, currentPage - maxPageButtons);
    let endPage = Math.min(totalPages, currentPage + maxPageButtons);
    if (startPage > 1) {
        pageButtons.push( <button key={1} onClick={() => paginate(1)}>1</button> );
        if (startPage > 2) { pageButtons.push(<span key={'ellipsis-start'}>...</span>); }
    }
    for (let i = startPage; i <= endPage; i++) {
        pageButtons.push( <button key={i} onClick={() => paginate(i)} className={i === currentPage ? 'active' : ''}> {i} </button> );
    }
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) { pageButtons.push(<span key={'ellipsis-end'}>...</span>); }
        pageButtons.push( <button key={totalPages} onClick={() => paginate(totalPages)}>{totalPages}</button> );
    }
    return pageButtons;
};

  return (

    <div>
      {/*nav cabesera principal */}
      <nav className="mi_navbar-fig">
        <div className="icon_mb displa_flex"> <button className='transparentis' onClick={toggleSidebar}> < FaBars /> </button> </div>
        <div className=" ps-5 alig_center displa_flex " > <Link to="/Administrador/InfoForoAdministrativoAdministrador"> <img className='imagenavbar' src={image_logo} alt="Imagen de navbar" /> </Link>  </div>

        <div className="search-container"> {/*Buscar por rut */}
          <FaSearch className="search-icon" />
          <input className='barra_bus_oper' type="text" placeholder="Buscar asociado" minLength={12} maxLength={12} value={busqueRUT} onChange={handbus} />
        </div>

        <div className="filters"> {/*Filtrador */}
          <div className="filter-item"> {/*Filtrador por Fecha */}
            <label htmlFor="filter-date"><FaCalendarAlt className='iconiti' /></label>
            <select id="filter-date" value={filtrarFecha} onChange={e => { setFiltrarFecha(e.target.value)}}>
              <option value="">Fecha Creacion</option>  
              {fecFec.sort((a, b) => new Date(b.split('-').reverse().join('/')) - new Date(a.split('-').reverse().join('/')))
              .map((fec, index) => ( <option key={index} value={fec}>{fec}</option> ))} 
            </select>
          </div>  
          <div className="filter-item"> {/*Filtrador por Estado */}
            <label htmlFor="filter-fill-status"><FaCheck className='iconiti' /></label>
            <select  id="filter-fill-status" value={filtrarEstado}  onChange={e => setFiltrarEstado(e.target.value)} >
              <option value="">Estado</option>  {estEst.map((est, index) => (  <option key={index} value={est}>{est}</option>  ))}
            </select>
          </div>
        </div>
        <div className='cerraSecion displa_flex '>
          {authenticated ? (  <div>  <button className='btn nav-link mb-2 ' onClick={handleLogout} ><FaSignOutAlt />  Cerrar sesión  </button>  </div>  ) : (  <div>  <Link className='btn nav-link mb-2 ' to="/LoginAdmin"><FaSignInAlt />  Iniciar sesión </Link>  </div>  )}
        </div> 
      </nav>
      {/* div despues del nav */}
      <div id='layoutSidenav' className={` ${sidebarVisible ? '' : 'layoutSidenav_nav-hidden'}`}>
        <Sidebar /> {/* barra lateral (Sidebar) */}
        {/* div del contenido que esta al lado de la barra lateral */}
        <div id="layoutSidenav_content" className={`${sidebarVisible ? '' : 'layoutSidenav_content-shifted'}`}>
          <div className='width100porciento'>
            <div className="pagination"> {renderPageButtons()} </div>
            <div className='listBins'>
              <h4 className='tituladmin'>Lista QR </h4> <br />
              <div className="bin-list">
                <div className="bin-cards">
                  {currentItems.map((item, index) => (
                    <div className="bin-card  ">
                      <div className="bin-info displa_flex  " key={index}  >
                         
                      
                          <div className='tex icon_mb displa_flex  ' > {/*  {item.qr || 'QR sin imagen'}  */} <img className='imagenavbar' src={image_logo} alt="Imagen de navbar" /></div>
                        
                        <div  >
                        <div className='tex' >  {item.rutAsociado }</div>
                        <div className='displa_flex separound_spas'>
                          <div className='tex' style={{'padding':'1px 10px'}} > {item.estado }</div> 
                          <div className='tex ' style={{'padding':'1px 10px'}}  > <input type="checkbox" /> Descargar </div>
                        </div>
                        <div className='tex' > Creación: {item.fechaCreado}</div>
                        
                        </div>
                        
                        
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
          </div>

      
        </div>
      </div>

    </div>

  )
};

export default ListaCodigosQR;



